{
  :type => 'aio',
  :pre_suite => [
    'setup/aio/pre-suite/010_Install.rb',
  ],
}
