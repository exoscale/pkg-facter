$LOAD_PATH << File.expand_path(File.dirname(__FILE__))
