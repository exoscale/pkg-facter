{
  :pre_suite => [
    'setup/common/00_EnvSetup.rb',
    'setup/packages/pre-suite/010_Install.rb',
  ],
}
